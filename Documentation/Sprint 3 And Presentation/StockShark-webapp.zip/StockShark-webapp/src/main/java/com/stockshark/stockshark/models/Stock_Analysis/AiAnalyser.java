package com.stockshark.stockshark.models.Stock_Analysis;

import java.util.List;

public class AiAnalyser implements iAi{


    @Override
    public void analyseData(List<String> stockSymbols) {
        // get stock data for each symbol
        // store it in the database
        // connect to open AI to get the prediction model to determine if stocks are good.
        // we can do text based to help the user understand what the values mean

    }
}
