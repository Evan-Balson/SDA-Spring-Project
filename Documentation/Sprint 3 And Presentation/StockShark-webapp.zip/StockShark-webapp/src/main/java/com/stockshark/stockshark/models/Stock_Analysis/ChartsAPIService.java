package com.stockshark.stockshark.models.Stock_Analysis;

import java.util.List;

public class ChartsAPIService implements iStockDisplay{


    @Override
    public void GenerateAreaChart(List<String> stockData) {
        //insert chart generation logic here
    }

    @Override
    public void GenerateAreaChartByDateRange(List<String> stockSymbols,String date1, String date2) {
        //insert chart generation logic here
    }
}
