package com.stockshark.stockshark.models.Stock_Analysis;

import java.util.List;

public interface iAi {
    void analyseData(List<String> stockSymbols);

}
