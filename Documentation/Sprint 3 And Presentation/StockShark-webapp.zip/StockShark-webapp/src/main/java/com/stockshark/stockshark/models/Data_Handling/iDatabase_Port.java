package com.stockshark.stockshark.models.Data_Handling;

public interface iDatabase_Port {

}
